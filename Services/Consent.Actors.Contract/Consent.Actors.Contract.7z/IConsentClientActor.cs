﻿namespace Consent.Actors.Contract
{
    public interface IConsentClientActor
    {

    }
}