﻿namespace Consent.Api.Model
{
    public class App
    {
        public int Id { get; set; }
        public string? Name { get; set; }
    }
}
