﻿namespace Consent.Api.Model
{
    public class Flow
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
